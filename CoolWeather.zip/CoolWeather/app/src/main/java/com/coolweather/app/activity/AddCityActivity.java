package com.coolweather.app.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.coolweather.app.R;
import com.coolweather.app.model.County;
import com.coolweather.app.model.CoolWeatherDB;


import java.util.ArrayList;
import java.util.List;

public class AddCityActivity extends Activity implements View.OnClickListener{
    private ListView listView;
    private TextView titleText;
    private ArrayAdapter<String> adapter;
    private List<String> dataList = new ArrayList<String>();
    private CoolWeatherDB coolWeatherDB;
    /**
     * 已添加县级列表
     */
    private List<County> addCountyList;
    private County addCounties;

    private Button addCity;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        setContentView(R.layout.add_cities);
        listView  = (ListView) findViewById(R.id.county_list);
        titleText = (TextView) findViewById(R.id.title2_text);
        adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,dataList);
        listView.setAdapter(adapter);
        coolWeatherDB = CoolWeatherDB.getInstance(this);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String countyCode =getIntent().getStringExtra("county_code");
                listView.setVisibility(View.VISIBLE);
                Log.i("111111",countyCode);
                addCountyList = coolWeatherDB.loadCounties(addCounties.getId());
                if (addCountyList.size()>0){
                    dataList.clear();
                    for (County county : addCountyList){
                        dataList.add(county.getCountyName());
                    }
                    adapter.notifyDataSetChanged();
                    listView.setSelection(0);
                    Intent intent = new Intent(AddCityActivity.this,WeatherActivity.class);
                    intent.putExtra("county_code",countyCode);
                    startActivity(intent);
                    finish();
                }


            }
        });
        addCity = (Button) findViewById(R.id.add_city);
        addCity.setOnClickListener(this);


    }


    @Override
    public  void  onClick(View v){
       switch (v.getId()){
           case R.id.add_city:

            Intent intent = new Intent(this,ChooseAreaActivity.class);
            intent.putExtra("from_AddCity_Activity",true);
            startActivity(intent);
            finish();
            break;

            default:
                break;
        }

    }

    @Override
    public void onBackPressed(){
        Intent intent = new Intent(this,WeatherActivity.class);
        startActivity(intent);
    }




}
